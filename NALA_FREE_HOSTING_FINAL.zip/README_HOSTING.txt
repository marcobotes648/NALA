NALA FREE HOSTING

This folder is ready to be uploaded as the root of a GitHub Pages site.

IMPORTANT:
- Do NOT change the Supabase project URL or key in index.html.
- Supabase email confirmation now redirects to the HTTPS address where NALA is running.
- After GitHub Pages is enabled, set Supabase Authentication > URL Configuration:
  Site URL = your NALA GitHub Pages HTTPS address
  Redirect URL = your NALA GitHub Pages HTTPS address
- Keep the existing Supabase database/schema. Do not rerun the old schema just to host the app.

The app also accepts Supabase confirmation tokens from the URL hash and stores the access token before returning to NALA.
