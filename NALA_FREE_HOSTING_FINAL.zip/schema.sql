-- NALA DATABASE
create extension if not exists pgcrypto;
create table if not exists public.properties (
 id uuid primary key default gen_random_uuid(), name text not null, city text not null,
 type text default 'Guesthouse', price numeric(12,2) not null default 0, rooms integer not null default 1,
 amenities text default 'Wi-Fi', active boolean not null default true, created_at timestamptz not null default now()
);
create table if not exists public.bookings (
 id uuid primary key default gen_random_uuid(),
 booking_ref text unique not null default ('NLA-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,8))),
 property_id uuid not null references public.properties(id) on delete restrict,
 guest_name text not null, guest_email text, check_in date not null, nights integer not null check(nights>0),
 guests integer not null default 1 check(guests>0), total_amount numeric(12,2) not null default 0,
 status text not null default 'confirmed', created_at timestamptz not null default now()
);
create table if not exists public.ai_tasks (
 id uuid primary key default gen_random_uuid(), title text not null, body text not null,
 status text not null default 'pending', created_at timestamptz not null default now()
);
alter table public.properties enable row level security;
alter table public.bookings enable row level security;
alter table public.ai_tasks enable row level security;
drop policy if exists "nala_public_properties" on public.properties;
create policy "nala_public_properties" on public.properties for select using (active=true);
drop policy if exists "nala_test_insert_properties" on public.properties;
create policy "nala_test_insert_properties" on public.properties for insert with check(true);
drop policy if exists "nala_test_insert_bookings" on public.bookings;
create policy "nala_test_insert_bookings" on public.bookings for insert with check(true);
drop policy if exists "nala_test_read_bookings" on public.bookings;
create policy "nala_test_read_bookings" on public.bookings for select using(true);
drop policy if exists "nala_test_read_tasks" on public.ai_tasks;
create policy "nala_test_read_tasks" on public.ai_tasks for select using(true);
drop policy if exists "nala_test_insert_tasks" on public.ai_tasks;
create policy "nala_test_insert_tasks" on public.ai_tasks for insert with check(true);
drop policy if exists "nala_test_update_tasks" on public.ai_tasks;
create policy "nala_test_update_tasks" on public.ai_tasks for update using(true) with check(true);
insert into public.properties(name,city,type,price,rooms,amenities)
select * from (values
('Welkom Central Guesthouse','Welkom','Guesthouse',850,8,'Breakfast · Wi-Fi · Parking'),
('Goldfields Hotel','Welkom','Hotel',1250,24,'Breakfast · Dinner · Wi-Fi'),
('Klerksdorp Lodge','Klerksdorp','Lodge',980,12,'Pool · Wi-Fi · Parking')
) v(name,city,type,price,rooms,amenities)
where not exists(select 1 from public.properties);


-- PARTNER V1 ADDITIONS
alter table public.properties add column if not exists owner_name text;
alter table public.properties add column if not exists owner_email text;
alter table public.properties add column if not exists approval_status text not null default 'approved';

drop policy if exists "nala_test_insert_properties" on public.properties;
create policy "nala_partner_insert_properties" on public.properties
for insert with check (true);

drop policy if exists "nala_partner_read_all_properties" on public.properties;
create policy "nala_partner_read_all_properties" on public.properties
for select using (true);

drop policy if exists "nala_admin_update_properties" on public.properties;
create policy "nala_admin_update_properties" on public.properties
for update using (true) with check (true);


-- =========================
-- NALA ACCOUNTS V1
-- Run ONLY this section if the previous NALA schema is already installed.
-- =========================

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'guest'
    check (role in ('guest','partner','admin')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "nala_profile_read_own" on public.profiles;
create policy "nala_profile_read_own"
on public.profiles for select
using (auth.uid() = id);

drop policy if exists "nala_profile_insert_own" on public.profiles;
create policy "nala_profile_insert_own"
on public.profiles for insert
with check (auth.uid() = id);

drop policy if exists "nala_profile_update_own" on public.profiles;
create policy "nala_profile_update_own"
on public.profiles for update
using (auth.uid() = id)
with check (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles(id, full_name, role)
  values(
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name',''),
    'guest'
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row
execute procedure public.handle_new_user();

alter table public.properties
  add column if not exists owner_id uuid references auth.users(id);

alter table public.bookings
  add column if not exists guest_id uuid references auth.users(id);
