NALA ACCOUNTS V1 FIXED

This version is built directly from the working NALA Partner V1.

1. Run ONLY the section named "NALA ACCOUNTS V1" in schema.sql.
2. Press Run in Supabase.
3. Replace the index.html used by your current NALA app.
4. Open NALA.

The database connection is left unchanged. If the account system fails, NALA will still show the exact Supabase connection status instead of getting stuck on Connecting.

Accounts:
- Guest sign-up
- Guest login
- Logout
- Persistent login on the phone
- Login required before booking
- Guest / partner / admin role foundation
